package com.example.starwars.ui.navigation

enum class Screens(val route: String) {
    Principal("principal"),
    ListaCompleta("listaCompleta"),
    Favoritos("favoritos"),
    Detalles("detalles/{personaje}")
}

