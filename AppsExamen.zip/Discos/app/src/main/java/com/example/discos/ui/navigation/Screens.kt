package com.example.discos.ui.navigation

enum class Screens {
    HOME, // Pantalla principal con la lista de discos
    DETALLES, // Pantalla de detalle del disco seleccionado
    AGREGAR // Pantalla para añadir nuevos discos
}

