package com.example.trivila2.ui.state

enum class Pantallas {
    HOME,
    GAME,
    ENDGAME,
    LOADING
}