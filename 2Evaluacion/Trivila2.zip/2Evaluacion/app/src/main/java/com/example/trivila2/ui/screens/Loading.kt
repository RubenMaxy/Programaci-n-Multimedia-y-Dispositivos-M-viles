package com.example.trivila2.ui.screens

import androidx.compose.runtime.Composable

@Composable
fun Loading() {

}