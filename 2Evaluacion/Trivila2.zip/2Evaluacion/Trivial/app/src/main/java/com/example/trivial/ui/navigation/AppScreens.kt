package com.example.trivial.ui.navigation

enum class AppScreens {
    HOME,
    GAME,
    ENDGAME
}