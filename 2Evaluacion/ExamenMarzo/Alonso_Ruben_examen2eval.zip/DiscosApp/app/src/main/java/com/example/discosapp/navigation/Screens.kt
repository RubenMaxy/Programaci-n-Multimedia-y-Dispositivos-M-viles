package com.example.discosapp.navigation

enum class Pantallas {
    HOME,
    DETALLE,
    ANADIR
}